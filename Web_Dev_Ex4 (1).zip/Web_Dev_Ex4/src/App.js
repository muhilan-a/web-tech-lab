
import './App.css';

import React from "react";
import EmployeeFilter from "./EmployeeFilter";

const employees = [
  { name: "Tony Stark", department: "IT" },
  { name: "Peter Parker", department: "Pizza Delivery" },
  { name: "Bruce Wayne", department: "IT" },
  { name: "Clark Kent", department: "Editing" },
  { name: "Barath Viknesh", department: "Pizza Delivery" },
  { name: "Muthu Palaniappan", department: "IT" },
  { name: "Raaghav P", department: "Editing" },
  { name: "Samyuktha S", department: "Pizza Delivery" },
  { name: "Raveesh R", department: "IT" },
  { name: "Adithya Varun", department: "Editing" },

];

const App = () => {
  return (
    <div className="App">
      <h1>Employees</h1>
      <EmployeeFilter employees={employees} />
    </div>
  );
};

export default App;

/* Pros and Cons of Each Method:

Drop-down List:

Pros: Provides a predefined list of options for filtering, making it easier for users to select from available choices. Suitable for scenarios where the user is likely to know the available departments.
Cons: Limited to selecting from the provided options. May not be ideal for scenarios where there are a large number of departments.

Search Text Box:

Pros: Offers more flexibility as users can enter any text they want to search for. Suitable for scenarios where users might want to search based on various criteria beyond just departments.
Cons: Requires users to manually type in search terms, which could lead to typos or inconsistent searches. Might not be suitable if the user is not familiar with the available employee names or departments.

My Preference:
I will use the search text box if it the options are not limited. For Example, if the data is text data, i would prefer the search text box.
If the data contains categorical values, I will use Drop down list. 
*/
