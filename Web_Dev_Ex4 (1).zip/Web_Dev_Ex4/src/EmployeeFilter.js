import React, { useState } from "react";

const EmployeeFilter = ({ employees }) => {
  const [selectedDepartment, setSelectedDepartment] = useState("All");
  const [searchText, setSearchText] = useState("");

  const handleDepartmentChange = (event) => {
    setSelectedDepartment(event.target.value);
  };

  const handleSearchChange = (event) => {
    setSearchText(event.target.value);
  };

  const filteredEmployees = employees.filter((employee) => {
    const departmentMatch =
      selectedDepartment === "All" ||
      employee.department === selectedDepartment;
    const nameMatch = employee.name.toLowerCase().includes(searchText.toLowerCase());
    return departmentMatch && nameMatch;
  });

  return (
    <div>
      <div>
        <label>Filter by Department:</label>
        <select value={selectedDepartment} onChange={handleDepartmentChange}>
          <option value="All">All</option>
          <option value="IT">IT</option>
          <option value="Pizza Delivery">Pizza Delivery</option>
          <option value="Editing">Editing</option>
        </select>
      </div>
      <div>
        <label>Search by Name:</label>
        <input type="text" value={searchText} onChange={handleSearchChange} />
      </div>
      <ul>
        {filteredEmployees.map((employee, index) => (
          <li key={index}>{employee.name} - {employee.department}</li>
        ))}
      </ul>
    </div>
  );
};

export default EmployeeFilter;
