// src/components/Navbar.js
import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const Nav = styled.nav`
  background-color: #fff;
  color: #000; 
  padding: 1.5rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const Logo = styled.img`
  width: 300px; 
`;

const NavList = styled.ul`
  list-style: none;
  display: flex;
  gap: 20px;
  margin: 0;
  padding: 0;
`;

const NavItem = styled.li`
  font-weight: bold;
  font-family: 'Your Professional Font', sans-serif; /* Replace with the actual font */
`;

const NavLink = styled(Link)`
  text-decoration: none;
  color: #333; 
  transition: color 0.3s ease-in-out;

  &:hover {
    color: #007bff;
  }
`;

const Navbar = () => {
  return (
    <Nav>
      <Logo src={require("../images/ramco_logo.png")} alt='logo' className="cursor-pointer" />
      <NavList>
        <NavItem>
          <NavLink to="/">Home</NavLink>
        </NavItem>
        <NavItem>
          <NavLink to="/about">About Us</NavLink>
        </NavItem>
        <NavItem>
          <NavLink to="/innovation">Innovation</NavLink>
        </NavItem>
        <NavItem>
          <NavLink to="/investors">Investors</NavLink>
        </NavItem>
        <NavItem>
          <NavLink to="/offerings">Offerings</NavLink>
        </NavItem>
        <NavItem>
          <NavLink to="/sustainability">Sustainability</NavLink>
        </NavItem>
      </NavList>
    </Nav>
  );
};

export default Navbar;
