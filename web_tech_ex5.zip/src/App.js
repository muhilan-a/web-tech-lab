import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './components/home';
import About from './components/about_us';
import Innovation from './components/innovation';
import Investors from './components/investors';
import Offerings from './components/offerings';
import Sustainability from './components/sustainability';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/innovation" element={<Innovation />} />
        <Route path="/investors" element={<Investors />} />
        <Route path="/offerings" element={<Offerings />} />
        <Route path="/sustainability" element={<Sustainability />} />
      </Routes>
    </Router>
  );
}

export default App;
