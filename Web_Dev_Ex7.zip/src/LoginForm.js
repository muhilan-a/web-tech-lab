
import React, { Component } from 'react';
import './App.css'; 

class LoginForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
    };
  }

  handleInputChange = (event) => {
    const { name, value } = event.target;
    this.setState({ [name]: value });
  };

  handleLogin = () => {
    const { username, password } = this.state;
    console.log("Logging in with:", username, password);
    this.props.onLogin(username, password);
  };

  render() {
    const { name,username, password } = this.state;

    return (
      <div className="login-container">
        <h2 className="login-heading">Login</h2>
        <input
          className="login-input"
          type="text"
          name="Name"
          placeholder="Name"
          value={name}
          onChange={this.handleInputChange}
        />
        <input
          className="login-input"
          type="text"
          name="username"
          placeholder="Username"
          value={username}
          onChange={this.handleInputChange}
        />
        <input
          className="login-input"
          type="password"
          name="password"
          placeholder="Password"
          value={password}
          onChange={this.handleInputChange}
        />
        <button className="login-button" onClick={this.handleLogin}>
          Login
        </button>
        
        <h2 className="credential-heading">Login Info Table</h2>
        <table className="user-table" >
          <thead>
            <tr>
              <th>Name</th>
              <th>Username</th>
              <th>Password</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Raveesh</td>
              <td>raveesh</td>
              <td>Raveesh1</td>
            </tr>
            <tr>
              <td>Krithik</td>
              <td>krithik</td>
              <td>Krithik1</td>
            </tr>
            <tr>
              <td>Muthu</td>
              <td>muthu</td>
              <td>Muthu1</td>
            </tr>
            <tr>
              <td>Raaghav</td>
              <td>raaghav</td>
              <td>Raaghav1</td>
            </tr>
            <tr>
             <td>Navin</td>
              <td>navin</td>
              <td>Navin1</td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

export default LoginForm;
