
import React from 'react';
import './App.css'; 

const WelcomeComponent = ({name, username, onLogout }) => {
  return (
    <div className="container"> 
      <h1 className="heading">Welcome, {username}!</h1> 

      <button className="login-button" onClick={onLogout}>
        Logout 
      </button>
    </div>
  );
};

export default WelcomeComponent;
