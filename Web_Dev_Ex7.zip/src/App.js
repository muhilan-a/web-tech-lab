// App.js
import React, { Component } from 'react';
import LoginForm from './LoginForm';
import WelcomeComponent from './Welcome';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentUser: null,
    };
  }

  localUsers = [
    { username: 'krithik', password: 'Krithik1' },
    { username: 'raveesh', password: 'Raveesh1' },
    { username: 'muthu', password: 'Muthu1' },
    { username: 'raaghav', password: 'Raaghav1' },
    { username: 'navin', password: 'Navin1' },

  ];

  handleLogin = ( username, password) => {
    const user = this.localUsers.find(
      (u) => u.username === username && u.password === password
    );

    if (user) {
      this.setState({ currentUser: user });
    } else {
      alert('Invalid username or password');
    }
  };

  handleLogout = () => {
    this.setState({ currentUser: null });
  };

  render() {
    const { currentUser } = this.state;

    return (
      <div className="App">
        {currentUser ? (
          <WelcomeComponent
            username={currentUser.username}
            onLogout={this.handleLogout}
          />
        ) : (
          <LoginForm onLogin={this.handleLogin} />
        )}
      </div>
    );
  }
}

export default App;
