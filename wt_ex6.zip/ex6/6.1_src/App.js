import React, { useState } from "react";
import "./App.css";

const App = () => {
const [number, setCounter] = useState(0)


const increment = () => {
	setCounter(number + 1)
}
const decrement = () => {
	setCounter(number - 1)
}

return (
  <div className="App">
    <h1>Counter App</h1>
    <p>Count: {number}</p>
    <button onClick={decrement}>Decrement</button>
    <button onClick={increment}>Increment</button>
  </div>
);
}

export default App;