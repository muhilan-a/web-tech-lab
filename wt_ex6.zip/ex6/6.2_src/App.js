import React, { useState } from 'react';
import './App.css';

function App() {
  const [principal, setPrincipal] = useState('');
  const [rate, setRate] = useState('');
  const [years, setYears] = useState('');
  const [simpleInterest, setSimpleInterest] = useState('');
  const [compoundInterest, setcompoundInterest] = useState('');  


  const calculateInterest = () => {
    const principalAmount = parseFloat(principal);
    const interestRate = parseFloat(rate);
    const numberOfYears = parseFloat(years);

    const interest = (principalAmount * interestRate * numberOfYears) / 100;
    const cinterest= (principalAmount*((1+interestRate/100)**numberOfYears)- principalAmount)

    setSimpleInterest(interest.toFixed(2));
    setcompoundInterest(cinterest.toFixed(2));

  };

  const resetFields = () => {
    setPrincipal('');
    setRate('');
    setYears('');
    setSimpleInterest('');
    setcompoundInterest('');

  };

  return (
    <div className="App">
      <h1>Simple Interest Calculator</h1>
      <div>
        <label>Principal Amount:</label>
        <input
          type="number"
          value={principal}
          onChange={(e) => setPrincipal(e.target.value)}
        />
      </div>
      <div>
        <label>Rate of Interest:</label>
        <input
          type="number"
          value={rate}
          onChange={(e) => setRate(e.target.value)}
        />
      </div>
      <div>
        <label>Number of Years:</label>
        <input
          type="number"
          value={years}
          onChange={(e) => setYears(e.target.value)}
        />
      </div>
      <button onClick={calculateInterest}>Calculate</button>
      <button onClick={resetFields}>Reset</button>
      {simpleInterest !== '' && (
        <p>Simple Interest: {simpleInterest}</p>
      )}
      {compoundInterest !== '' && (
        <p>Compound Interest: {compoundInterest}</p>
      )}

    </div>
  );
}

export default App;
